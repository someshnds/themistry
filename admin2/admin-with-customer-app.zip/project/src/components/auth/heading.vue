<template>
  <div class='sm:mx-auto sm:w-full sm:max-w-md'>
    <img :alt='this.$settings["app_name"]' :src='this.$settings["app_logo"]'
         class='mx-auto h-14 w-auto' />
  </div>
</template>