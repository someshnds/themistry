<template>
  <div class=' w-full flex flex-col items-center justify-center gap-y-3'>
    <span class='text-xl font-bold text-second-color-200 '>{{ $t('Empty FAQ List') }}</span>
    <span class='text-second-color-200'>{{ $t('Empty FAQ List Message') }}</span>
  </div>
</template>