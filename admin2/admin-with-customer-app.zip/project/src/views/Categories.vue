<template>
  <Heading />
  <Categories />
</template>

<script>

import Heading from '../components/categories/heading.vue'
import Categories from '../components/categories/categories_grid.vue'

export default {
  components: {
    Heading,
    Categories,
  },
}

</script>
